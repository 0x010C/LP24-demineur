package control;

public interface SpinnerListener {
	public void update();
}
