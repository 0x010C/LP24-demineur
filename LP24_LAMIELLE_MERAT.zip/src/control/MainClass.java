package control;

public class MainClass {
	public static void main(String[] args) {
		WindowManager mainManager = new WindowManager();
		mainManager.toString(); //only useful to remove the "unused attribute" warning
	}
}