package control;


public interface GameListener {
	public void revealing(int x, int y);
	public void flagging(int x, int y);
}